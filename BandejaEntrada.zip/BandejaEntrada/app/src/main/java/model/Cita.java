package model;

import android.os.Parcel;
import android.os.Parcelable;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class Cita implements Parcelable {
    private String id;
    private String tituloCita;
    private Persona emisor;
    private Persona receptor;
    private String fecha;
    private String hora;
    private int puntuacionEmisor;
    private int puntuacionReceptor;
    private String descripcion;
    private String lugar;
    private String nombreApellidosEmisor;


    public Cita(String tit, Persona e, Persona r, String f, String h, String desc, String l){
        this.tituloCita=tit;
        this.emisor=e;
        this.receptor=r;
        this.fecha=f;
        this.hora=h;
        this.puntuacionEmisor=0;
        this.puntuacionReceptor=0;
        this.descripcion=desc;
        this.lugar=l;
        this.nombreApellidosEmisor = e.getNombre()+ " " + e.getApellido();
    }

    protected Cita(Parcel in) {
        id = in.readString();
        tituloCita = in.readString();
        fecha = in.readString();
        hora = in.readString();
        puntuacionEmisor = in.readInt();
        puntuacionReceptor = in.readInt();
        descripcion = in.readString();
        lugar = in.readString();
        nombreApellidosEmisor = in.readString();
    }

    public static final Creator<Cita> CREATOR = new Creator<Cita>() {
        @Override
        public Cita createFromParcel(Parcel in) {
            return new Cita(in);
        }

        @Override
        public Cita[] newArray(int size) {
            return new Cita[size];
        }
    };

    public void setPuntuacionEmisor(int p){
        this.puntuacionEmisor=p;
    }
    public void setPuntuacionReceptor(int p){
        this.puntuacionReceptor=p;
    }
    public Persona getEmisor(){
        return this.emisor;
    }

    public String getTituloCita() {
        return tituloCita;
    }

    public Persona getReceptor() {
        return receptor;
    }

    @Override
    public String toString() {
        return "Cita{" +
                "id='" + id + '\'' +
                ", tituloCita='" + tituloCita + '\'' +
                ", emisor=" + emisor +
                ", receptor=" + receptor +
                ", fecha='" + fecha + '\'' +
                ", hora='" + hora + '\'' +
                ", puntuacionEmisor=" + puntuacionEmisor +
                ", puntuacionReceptor=" + puntuacionReceptor +
                ", descripcion='" + descripcion + '\'' +
                ", lugar='" + lugar + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(tituloCita);
        parcel.writeString(fecha);
        parcel.writeString(hora);
        parcel.writeInt(puntuacionEmisor);
        parcel.writeInt(puntuacionReceptor);
        parcel.writeString(descripcion);
        parcel.writeString(lugar);
        parcel.writeString(nombreApellidosEmisor);
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getNombreApellidosEmisor(){
        return nombreApellidosEmisor;
    }
}
