package model;

import android.media.Image;
import android.net.Uri;

public class Persona {
    private String fotoPerfilUrl;
    private String nombre;
    private String apellido;
    private int edad;

    public String getFotoPerfilUrl() {
        return fotoPerfilUrl;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public Persona(String fotoPerfil, String name, String surname, int age){
        this.fotoPerfilUrl=fotoPerfil;
        this.nombre=name;
        this.apellido=surname;
        this.edad=age;
    }
}
