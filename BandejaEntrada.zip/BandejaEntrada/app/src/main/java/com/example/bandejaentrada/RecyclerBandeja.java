package com.example.bandejaentrada;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import model.Cita;
import model.Persona;

public class RecyclerBandeja extends AppCompatActivity {
    public static final String CITA_SELECCIONADA = "cita_seleccionada";
    private List<Cita> listaCitas=new ArrayList<>();
    private RecyclerView listaCitaView;
    private Button btVer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_bandeja);
        Persona p1=new Persona("res/drawable-v24/imagen1.png", "Nombre1", "Apellido1", 20);
        Persona p2=new Persona("res/drawable-v24/imagen1.png","Nombre2", "Apellido2", 21);
        listaCitas.add(new Cita("Comida", p1,p2,"12/10/2022", "12:00", "No desc", "Eii"));
        listaCitas.add(new Cita("Cine", p1,p2,"15/12/2023", "19:00", "Vamos a ver Spiderman", "Yelmo cines"));
        listaCitas.add(new Cita("Cena", p1,p2,"11/02/2023", "21:00", "Una McDonald's o que", "McDonalds"));
        cargarView();
    }

    protected void cargarView(){
        listaCitaView=(RecyclerView) findViewById(R.id.reciclerBandeja);
        this.btVer=(Button)findViewById(R.id.buttonVerSolicitud);
        listaCitaView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        listaCitaView.setLayoutManager(layoutManager);
        ListaCitasAdapter adapter=new ListaCitasAdapter(listaCitas, new ListaCitasAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Cita item) {
                clickOnItem(item);
            }
        });
        listaCitaView.setAdapter(adapter);

    }

    public void clickOnItem(Cita cita) {
        Intent intent = new Intent(RecyclerBandeja.this, ShowCita.class);
        intent.putExtra(CITA_SELECCIONADA, cita);

        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }


}