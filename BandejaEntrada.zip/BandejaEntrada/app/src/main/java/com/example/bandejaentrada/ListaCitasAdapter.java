package com.example.bandejaentrada;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import model.Cita;
import model.Persona;

public class ListaCitasAdapter extends RecyclerView.Adapter<ListaCitasAdapter.CitaViewHolder>{

    public interface OnItemClickListener {
        void onItemClick(Cita item);
    }
    private List<Cita> listaCitas;
    private final OnItemClickListener listener;
    public ListaCitasAdapter(List<Cita> lista, OnItemClickListener listener){
        this.listaCitas=lista;
        this.listener = listener;
    }





    @Override
    public int getItemCount() {
        Log.i("Tamaño lista: ",listaCitas.size()+"");
        return listaCitas.size();
    }

    public static class CitaViewHolder extends RecyclerView.ViewHolder{

        private TextView tituloCita;
        private TextView nombrePersonaCita;
        private ImageView fotoPersonaCita;

        public CitaViewHolder(View itemView){
            super(itemView);

            tituloCita = (TextView)itemView.findViewById(R.id.tituloCita);
            nombrePersonaCita =(TextView)itemView.findViewById(R.id.nombrePersonaCita);
            fotoPersonaCita =(ImageView) itemView.findViewById(R.id.fotoPersonaCita);

        }

        public void bindUser(final Cita cita, final Persona emisor, final OnItemClickListener listener){
            tituloCita.setText(cita.getTituloCita());
            nombrePersonaCita.setText(emisor.getNombre()+" "+emisor.getApellido());
            Picasso.get().load(emisor.getFotoPerfilUrl()).into(fotoPersonaCita);
            Log.i("Adapter", emisor.getFotoPerfilUrl());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    listener.onItemClick(cita);
                }
            });
        }
    }

    @NonNull
    @Override
    public CitaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.linea_recycler_bandeja, parent, false);
        return new CitaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CitaViewHolder holder, int position) {
        Cita c=listaCitas.get(position);
        Persona emisor=c.getEmisor();
        holder.bindUser(c,emisor,listener);
    }

}
