package com.example.bandejaentrada;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.bandejaentrada.databinding.ActivityShowCitaBinding;

import model.Cita;

public class ShowCita<descripcion> extends AppCompatActivity {

    private Cita cita;

    CollapsingToolbarLayout toolbarLayout;
    TextView titulo;
    TextView emisor;
    TextView fecha;
    TextView hora;
    TextView descripcion;
    TextView lugar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_cita);

        Intent intentPeli = getIntent();
        cita = intentPeli.getParcelableExtra(RecyclerBandeja.CITA_SELECCIONADA);

        titulo = (TextView) findViewById(R.id.titulo);
        emisor = (TextView) findViewById(R.id.emisor);
        fecha = (TextView) findViewById(R.id.fecha);
        hora = (TextView) findViewById(R.id.hora);
        descripcion = (TextView) findViewById(R.id.descripcion);
        lugar = (TextView) findViewById(R.id.lugar);

        if (cita != null)
            mostrarDatos(cita);
    }

    private void mostrarDatos(Cita cita) {
        if (!cita.getTituloCita().isEmpty()){
            titulo.setText(cita.getTituloCita());
            emisor.setText(cita.getNombreApellidosEmisor());
            this.fecha.setText(cita.getFecha());
            hora.setText(cita.getHora());
            descripcion.setText(cita.getDescripcion());
            lugar.setText(cita.getLugar());
        }
    }
}