package com.example.bandejaentrada;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import model.Cita;
import model.Persona;

public class NuevaCitaActivity extends AppCompatActivity {
    private EditText editTextFecha;
    private EditText editTextHora;
    private EditText editTextLugar;
    private EditText editTextTitulo;
    private EditText editTextDescripcion;
    private Button buttonEnviarCita;
    private Persona emisor;
    private Persona receptor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_cita);
        this.editTextFecha=(EditText) findViewById(R.id.editTextFecha);
        this.editTextHora=(EditText) findViewById(R.id.editTextHora);
        this.editTextLugar=(EditText)findViewById(R.id.editTextLugar);
        this.editTextTitulo=(EditText)findViewById(R.id.editTextTitulo);
        this.editTextDescripcion=(EditText) findViewById(R.id.textDescripcion);
        this.buttonEnviarCita=(Button) findViewById(R.id.buttonEnviarCita);


        buttonEnviarCita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarCampos()) {
                    Cita c= new Cita(editTextTitulo.getText().toString(), emisor, receptor, editTextFecha.getText().toString(), editTextHora.getText().toString(),
                            editTextDescripcion.getText().toString(), editTextLugar.getText().toString());
                    Log.i("nuevaCita",c.toString());
                }

            }
        });
    }


    private boolean validarCampos() {
        if (editTextFecha.getText().toString().isEmpty()) {
            editTextFecha.setError("No fecha");
            editTextFecha.requestFocus();
            return false;
        }
        if (editTextHora.getText().toString().isEmpty()) {
            editTextHora.setError("No hora");
            editTextHora.requestFocus();
            return false;
        }
        if (editTextLugar.getText().toString().isEmpty()) {
            editTextLugar.setError("No lugar");
            editTextLugar.requestFocus();
            return false;
        }
        if (editTextTitulo.getText().toString().isEmpty()) {
            editTextTitulo.setError("No titulo");
            editTextTitulo.requestFocus();
            return false;
        }

        return true;
    }

}
