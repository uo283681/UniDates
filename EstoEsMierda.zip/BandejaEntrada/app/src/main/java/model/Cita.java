package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class Cita {
    private String id;
    private String tituloCita;
    private Persona emisor;
    private Persona receptor;
    private String fecha;
    private String hora;
    private int puntuacionEmisor;
    private int puntuacionReceptor;
    private String descripcion;
    private String lugar;


    public Cita(String tit, Persona e, Persona r, String f, String h, String desc, String l){
        this.tituloCita=tit;
        this.emisor=e;
        this.receptor=r;
        this.fecha=f;
        this.hora=h;
        this.puntuacionEmisor=0;
        this.puntuacionReceptor=0;
        this.descripcion=desc;
        this.lugar=l;
    }

    public void setPuntuacionEmisor(int p){
        this.puntuacionEmisor=p;
    }
    public void setPuntuacionReceptor(int p){
        this.puntuacionReceptor=p;
    }
    public Persona getEmisor(){
        return this.emisor;
    }

    public String getTituloCita() {
        return tituloCita;
    }

    public Persona getReceptor() {
        return receptor;
    }

    @Override
    public String toString() {
        return "Cita{" +
                "id='" + id + '\'' +
                ", tituloCita='" + tituloCita + '\'' +
                ", emisor=" + emisor +
                ", receptor=" + receptor +
                ", fecha='" + fecha + '\'' +
                ", hora='" + hora + '\'' +
                ", puntuacionEmisor=" + puntuacionEmisor +
                ", puntuacionReceptor=" + puntuacionReceptor +
                ", descripcion='" + descripcion + '\'' +
                ", lugar='" + lugar + '\'' +
                '}';
    }
}
