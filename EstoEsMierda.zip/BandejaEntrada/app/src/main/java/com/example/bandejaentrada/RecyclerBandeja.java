package com.example.bandejaentrada;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import model.Cita;
import model.Persona;

public class RecyclerBandeja extends AppCompatActivity {
    private List<Cita> listaCitas=new ArrayList<>();
    private RecyclerView listaCitaView;
    private Button btVer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_bandeja);
        Persona p1=new Persona("res/drawable-v24/imagen1.png", "Nombre1", "Apellido1", 20);
        Persona p2=new Persona("res/drawable-v24/imagen1.png","Nombre2", "Apellido2", 21);
        listaCitas.add(new Cita("Comida", p1,p2,"12/10/2022", "12:00", "No desc", "Eii"));
        cargarView();
    }

    protected void cargarView(){
        listaCitaView=(RecyclerView) findViewById(R.id.reciclerBandeja);
        this.btVer=(Button)findViewById(R.id.buttonVerSolicitud);
        listaCitaView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        listaCitaView.setLayoutManager(layoutManager);
        ListaCitasAdapter adapter=new ListaCitasAdapter(listaCitas, new ListaCitasAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Cita item) {

            }
        });
        listaCitaView.setAdapter(adapter);

    }


}